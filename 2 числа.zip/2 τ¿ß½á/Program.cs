﻿using System;

namespace _2_числа
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите 1 число:");
            double a1=Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите 2 число:");
            double a2 = Convert.ToDouble(Console.ReadLine());
            bool x1 = (a1 < a2) && (a1 > a2);
            Console.WriteLine(x1);
            bool x2 = (a1 < a2) && (a1 < a2);
            Console.WriteLine(x2);
            bool y1 = (a1 < a2) || (a1 > a2);
            Console.WriteLine(y1);
            bool y2 = (a1 < a2) || (a1 < a2);
            Console.WriteLine(y2);
            Console.Write("Введите 1 число:");
            string b1 = Console.ReadLine();
            Console.Write("Введите 2 число:");
            string b2 = Console.ReadLine();
            bool z1 = (a1 < a2) && (a1 > a2);
            Console.WriteLine(x1);
            bool z2 = (a1 < a2) && (a1 < a2);
            Console.WriteLine(z2);
            bool c1 = (a1 < a2) || (a1 > a2);
            Console.WriteLine(y1);
            bool c2 = (a1 < a2) || (a1 < a2);
            Console.WriteLine(c2);
            bool A = a1 > a2;
            Console.WriteLine(A);
        }
    }
}
