﻿using System;
namespace Speed
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Масса (т)=");
            double M = Convert.ToDouble(Console.ReadLine());
            Console.Write("Радиус планеты (км)=");
            double R = Convert.ToDouble(Console.ReadLine());
            Console.Write("Высота над поверхностью планеты (км)=");
            double h = Convert.ToDouble(Console.ReadLine());
            double G1 = 6.67408;
            double G2= Convert.ToDouble(Math.Pow(10, -11));
            double G = G1 * G2;
            double V1 = G*M / (R + h);
            double V = Math.Sqrt(V1);
            Console.Write("Линейная скорость искусственного спутника Земли (км/ч)=");
            Console.Write(V);
        }
    }
}
